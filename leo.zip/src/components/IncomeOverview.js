import React, { useEffect, useState } from 'react';
import '../css/IncomeOverview.css';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebaseConfig';

const IncomeOverview = () => {
  const [indoorData, setIndoorData] = useState([]);
  const [outdoorData, setOutdoorData] = useState([]);
  const [investigationData, setInvestigationData] = useState([]);
  const [dressingData, setDressingData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const indoorSnap = await getDocs(collection(db, 'indoorSales'));
      const outdoorSnap = await getDocs(collection(db, 'outdoorSales'));
      const investigationSnap = await getDocs(collection(db, 'investigationSales'));
      const dressingSnap = await getDocs(collection(db, 'dressingSales'));

      setIndoorData(indoorSnap.docs.map(doc => doc.data()));
      setOutdoorData(outdoorSnap.docs.map(doc => doc.data()));
      setInvestigationData(investigationSnap.docs.map(doc => doc.data()));
      setDressingData(dressingSnap.docs.map(doc => doc.data()));
    };

    fetchData();
  }, []);

//   const renderTable = (title, data) => (
//     <div className="income-section">
//       <h2>{title}</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Date</th>
//             <th>Patient Name</th>
//             <th>Total Amount</th>
//           </tr>
//         </thead>
//         <tbody>
//           {data.map((entry, index) => (
//             <tr key={index}>
//               <td>{entry.date || '-'}</td>
//               <td>{entry.name || entry.customer || '-'}</td>
//               <td>Rs. {entry.total || entry.amount || 0}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
const renderTable = (title, data) => (
    <div className="income-section">
      <h2>{title}</h2>
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Patient Name</th>
              <th>Total Amount</th>
            </tr>
          </thead>
          <tbody>
            {data.map((entry, index) => (
              <tr key={index}>
                <td>{entry.date || '-'}</td>
                <td>{entry.name || entry.customer || '-'}</td>
                <td>Rs. {entry.total || entry.amount || 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );  

  return (
    <div className="income-overview">
      <h1>Income Overview</h1>
  
      {renderTable("Indoor Pharmacy", indoorData)}
      {renderTable("Outdoor Pharmacy", outdoorData)}
      {renderTable("Investigation", investigationData)}
      {renderTable("Dressing", dressingData)}
    </div>
  );  
};

export default IncomeOverview;
